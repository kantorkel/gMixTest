/*
 * Copyright (C) 2002 Brent N. Chun <bnc@caltech.edu>
 */
#ifndef __GEXEC_H
#define __GEXEC_H

#ifdef GANGLIA
#define GEXEC_GANGLIA_PORT    8649  /* Really should be in ganglia.h */
#endif /* GANGLIA */

#endif /* __GEXEC_H */
