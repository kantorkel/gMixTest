/* Define this to enable node selection using Ganglia */
#undef GANGLIA
