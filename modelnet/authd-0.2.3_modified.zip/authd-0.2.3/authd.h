/*
 * Copyright (C) 2002 Brent N. Chun <bnc@caltech.edu>
 */
#ifndef __AUTHD_H
#define __AUTHD_H

/* Maximum lifetime of a credential in seconds */
#define AUTHD_CRED_MAXLIFE   30

#endif /* __AUTHD_H */
